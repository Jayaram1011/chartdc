from inputdata.models import Outlier
from outputdata.models import Units

def get_units(assetdb):
    units = Units.objects.using(assetdb).all().values().first()
    return units if units else {}

def outlier_db_datalist(assetdb, userid):
    outlier_data = list(Outlier.objects.using(assetdb).filter(user_id=userid, Rate=True).values('UNIQUEID','date'))
    return outlier_data

