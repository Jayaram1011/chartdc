from django.urls import include, path

import DCAssistChart.DashComponents.otherphasesforecast
import DCAssistChart.DashComponents.otherphasesforecastcum
import DCAssistChart.DashComponents.probabilisticvsarithmetic
# Load demo plotly apps - this triggers their registration
import DCAssistChart.DashComponents.uniquewell

from.views import (otherphasesforecast_view, otherphasesforecastcum_view,
                    probabilisticvsarithmetic_view, uniquewell_view)

app_name = 'DCAssistChart'
urlpatterns = [
    path('uniquewell/', uniquewell_view, name="uniquewell"),
    
    path('otherphasesforecast/', otherphasesforecast_view, name="otherphasesforecast"),
    path('otherphasesforecastallcases/', otherphasesforecast_view, name="otherphasesforecastallcases"),
    
    path('otherphasesforecastcum/', otherphasesforecastcum_view, name="otherphasesforecastcum"),
    path('otherphasesforecastcumallcases/', otherphasesforecastcum_view, name="otherphasesforecastcumallcases"),
    
    path('probabilisticvsarithmetic/', probabilisticvsarithmetic_view, name="probabilisticvsarithmetic"),
    path('probabilisticvsarithmeticallcases/',probabilisticvsarithmetic_view, name="probabilisticvsarithmeticallcases"),
    
    ]