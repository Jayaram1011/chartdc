import logging
from datetime import datetime

from auditlog.helper import end_audit_log, start_audit_log
from DCAssist.settings import DOMAIN_NAME
from DCAssistChart.dbconnection import (
    DBConnection, delete_outlier_records_data,
    update_selected_outlier_for_next_runanalysis_data,
    update_startdate_enddate_decline_period_data)
from DCAssistChart.dbqueries import get_units

logger = logging.getLogger(__name__)


def get_wells_data(userid, assetdb, system):
    dbc = DBConnection()
    uniquewell_data = dbc.activewellsoutputdirwithnd(assetdb, userid)
    uniquewell_data['assetdb'] = assetdb
    uniquewell_data['domain'] = DOMAIN_NAME
    uniquewell_data['system'] = system
    uniquewell_data['units'] = get_units(assetdb)
    # uniquewell_data['outliers'] = dbc.get_outlier_db_data(assetdb, userid) 
    return uniquewell_data

def get_outliers_data(assetdb, userid):
    dbc = DBConnection()
    outlier_data = dbc.get_outlier_db_data(assetdb, userid) 
    return outlier_data

def outlier_format_date(str):
    return datetime.strptime(str,'%Y-%m-%d').strftime("%Y-%m-%d")

def select_box_data(selectedData, value, uniquewell_data, selectedcolumn):
    points = []
    uniquewell_selected_data = {}
    if selectedData:
        dates = []
        if selectedData['points']:
            points = selectedData['points']
            
            uniquewell_selected_data['assetdb'] = uniquewell_data["assetdb"]
            uniquewell_selected_data['user_id'] = uniquewell_data["userid"]
            uniquewell_selected_data['selected_column'] = selectedcolumn
            uniquewell_selected_data['well_id'] = value
        
            for point in points:
                dates.append(point['x'])
            date_list = [outlier_format_date(date) for date in dates]
            uniquewell_selected_data['selected_dates'] = date_list
        return uniquewell_selected_data
    return uniquewell_selected_data

def reset_outlier_data(uniqueid, asset_db, user_id):
    if user_id:
        try:
            audit_id = start_audit_log(asset_db, user_id,[uniqueid], 'resetOutliers')
            logger.info('Calling reset_outlier_data Fuction')
            delete_outlier_records_data(asset_db, user_id, uniqueid)
            end_audit_log(asset_db, audit_id, "success", "Outliers are reset", [uniqueid])
            return "Outlier data was reset!!!"
        except Exception as e:
            end_audit_log(asset_db, audit_id, "failure", str(e), [uniqueid])
            logger.error(e, exc_info=True)
            return "Exception occur while Reset Outiler."
    return "Failed to reset outiler. UserID not present."

def update_selected_outlier_data(uniqueid, asset_db, user_id, selected_date_list, selected_column):
    if user_id:
        try:
            audit_id = start_audit_log(asset_db, user_id, [uniqueid], 'removeOutliers')
            delete_outlier_records_data(asset_db, user_id, uniqueid)
            logger.info('Calling exclude_selected_data Fuction')
            update_selected_outlier_for_next_runanalysis_data(asset_db, uniqueid, user_id, selected_column, selected_date_list)            
            end_audit_log(asset_db, audit_id, "success", "Outliers are removed", [uniqueid])
            return "Outliers are Set. Refresh Page to See Outlier Changes !!!"
        except Exception as e:
            end_audit_log(user_id, audit_id, "failure", str(e), [uniqueid])
            logger.error(e, exc_info=True)
            return "Exception occur while updating selected outiler."
    return "Failed to update selected outiler. UserID not present."

def update_selected_dates_decline_period(uniqueid, asset_db, user_id, selected_date_list):
    if user_id:
        try :
            audit_id = start_audit_log(asset_db, user_id, [uniqueid], 'updateDateDeclinePeriod')
            selected_date_list.sort()
            decline_start_date = selected_date_list[0]
            decline_end_date = selected_date_list[-1]
            logger.info('Calling update decline date Function')
            update_startdate_enddate_decline_period_data(decline_start_date, decline_end_date, asset_db, uniqueid, user_id)
            end_audit_log(asset_db, audit_id, "success", "Updated Decline Period Start and End Date", [uniqueid])
            return "Decline Period selected box start and end date updated Successfully."
        except Exception as e:
            end_audit_log(asset_db, audit_id, "failure", str(e), [uniqueid])
            logger.error(e, exc_info=True)
            return "Exception occur while updating decline period start date and end date."
    return "Failed to update decline period. UserID not present."
 #otherphasesforecast
def get_otherphasesforecast_data(userid, assetdb, system, allcases):
    dbc = DBConnection()
    if system == True:
        otherphasesforecast_data = dbc.activewellsoutputdirwithndsys(assetdb,userid)
    else:
        otherphasesforecast_data  = dbc.activewellsoutputdir_withnd(assetdb,userid)

        otherphasesforecast_data['assetdb'] = assetdb
        otherphasesforecast_data['allcases'] = allcases
        otherphasesforecast_data['domain'] = DOMAIN_NAME
        otherphasesforecast_data['system'] = system
        otherphasesforecast_data['units'] = get_units(assetdb)
    return otherphasesforecast_data
 
 #otherphasesforecastcum
def get_otherphasesforecastcum_data(userid, assetdb, system, allcases):
    dbc = DBConnection()
    if system == True:
        otherphasesforecastcum_data = dbc.activewellsoutputdirwithndsys(assetdb,userid)
    else:
        otherphasesforecastcum_data  = dbc.activewellsoutputdir_with_nd(assetdb,userid)

        otherphasesforecastcum_data['assetdb'] = assetdb
        otherphasesforecastcum_data['allcases'] = allcases
        otherphasesforecastcum_data['domain'] = DOMAIN_NAME
        otherphasesforecastcum_data['system'] = system
        otherphasesforecastcum_data['units'] = get_units(assetdb)
    return otherphasesforecastcum_data

def get_probabilisticvsarithmetic_data(userid, assetdb, system, allcases):
    dbc = DBConnection()
    if system == True:
        probabilisticvsarithmetic_data = dbc.activewellsoutputdirwithndsys(assetdb,userid)
    else:
        probabilisticvsarithmetic_data  = dbc.activewellsoutputdir_with_nd(assetdb,userid)

        probabilisticvsarithmetic_data['assetdb'] = assetdb
        probabilisticvsarithmetic_data['allcases'] = allcases
        probabilisticvsarithmetic_data['domain'] = DOMAIN_NAME
        probabilisticvsarithmetic_data['system'] = system
        probabilisticvsarithmetic_data['units'] = get_units(assetdb)
    return probabilisticvsarithmetic_data




                




