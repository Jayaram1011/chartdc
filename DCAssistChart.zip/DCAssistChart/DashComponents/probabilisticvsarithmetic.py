import dash
import dash_bootstrap_components as dbc
from dash import ctx, dcc, html
from dash.dependencies import Input, Output, State
from django_plotly_dash import DjangoDash

from DCAssistChart.DashComponents.utils import \
    get_probabilisticvsarithmetic_data
from DCAssistChart.PlotlyComponents.probabilisticvsarithmetic_plot import (
    ratevscumulativearithmeticaggregation,
    ratevscumulativeprobabilisticaggregation, ratevsdatearithmeticaggregation,
    ratevsdateprobabilisticaggregation)

config = {'modeBarButtonsToRemove': ['lasso2d', 'hoverClosestCartesian', 'hoverCompareCartesian', 'toggleSpikelines'], 'displaylogo': False, 'displayModeBar': True}

app_probabilisticvsarithmetic = DjangoDash("probabilisticvsarithmetic", add_bootstrap_links=True)

app_probabilisticvsarithmetic.layout = html.Div([
                
        dbc.Col([
            html.Br(),
            html.H5('Unique ID'),
        ], style={'textAlign': 'center'}),

        html.Br(),  

        dcc.Store(id='probabilisticvsarithmetic_data_id', storage_type='memory'),

        dbc.Col([
            dcc.Dropdown(id='probabilisticvsarithmetic_dropdown_id',
                    options=[],
                    placeholder="Select",
                    style={'fontSize': "15px", 'textAlign': 'center'}),
            ], lg=8, className ="mw-100"), 
        html.Br(),
        dbc.Col([
	        html.P('This plot window shows rates and cumm parameter values for probabilistic and arithmetic aggregation.    ',style={'fontSize': "17px", 'textAlign': 'center','color':'black','background-color': '#FFFF00'}), 
	        html.P('Enlarge the Rate vs Date and Rate vs Cumulative Volume to see comparison with the benchmark case.',style={'fontSize': "17px", 'textAlign': 'center','color':'black','background-color': '#FFFF00'}),

         ],className ="mw-100 text-info"),
        dbc.Col([
                dcc.Link('Click for all cases',id='allcases_link_id',href='#',style={'width': '100%', 'display': 'inline-block','text-align': 'right'}),
                ],className ="mw-100 text-info"),

        dbc.Row([ 
                dcc.Loading(              
                        id="loading-1",
                        type="circle",
                        children= [ 
                                    dcc.Graph(id='ratevsdateprobabilisticaggregation',config=config, style={'width': '50%','display': 'inline-block'}),
                                    dcc.Graph(id='ratevscumulativeprobabilisticaggregation',config=config, style={'width': '50%','display': 'inline-block'}),

                                    ],
                    ),
                 dcc.Loading(
                       id="loading-2",
                          type="circle",
                          children=[
                                      dcc.Graph(id='ratevsdatearithmeticaggregation',config=config, style={'width': '50%','display': 'inline-block'}),
                                      dcc.Graph(id='ratevscumulativearithmeticaggregation',config=config, style={'width': '50%','display': 'inline-block'}),
                                      ],
                          ),
        ]),
            html.Br(),
     ])

@app_probabilisticvsarithmetic.callback(
    Output('probabilisticvsarithmetic_dropdown_id','options'),Output('probabilisticvsarithmetic_data_id','data'),Output('allcases_link_id', 'href'),
    Input('probabilisticvsarithmetic_data_id','data')
)
def dropdown_options(data, session_state=None): 
    probabilisticvsarithmetic_data = get_probabilisticvsarithmetic_data(session_state['userid'], session_state['assetdb'], session_state['system'],session_state['allcases'])

    if len(probabilisticvsarithmetic_data.get('uniqueids')) != 0:
        options = [{'label': i, 'value': i} for i in probabilisticvsarithmetic_data.get('uniqueids').keys()]
        
    else:
        options = []    
             
    if probabilisticvsarithmetic_data['system'] == 'true':   
        return options,probabilisticvsarithmetic_data,f'/chart/probabilisticvsarithmeticallcases/?userId={probabilisticvsarithmetic_data["userid"]}&system=true'
    else:
        return options,probabilisticvsarithmetic_data,f'/chart/probabilisticvsarithmeticallcases/?userId={probabilisticvsarithmetic_data["userid"]}'


@app_probabilisticvsarithmetic.callback(
    Output(component_id='ratevsdateprobabilisticaggregation', component_property='figure'),
    [Input("probabilisticvsarithmetic_dropdown_id", "value"),Input('probabilisticvsarithmetic_data_id', 'data')],)
def plot_ratevsdateprobabilisticaggregation(value, probabilisticvsarithmetic_data):
        return ratevsdateprobabilisticaggregation(dropdown_value=value,probabilisticvsarithmetic_data=probabilisticvsarithmetic_data)

    
@app_probabilisticvsarithmetic.callback(
    Output(component_id='ratevscumulativeprobabilisticaggregation', component_property='figure'),
    [Input("probabilisticvsarithmetic_dropdown_id", "value"),Input('probabilisticvsarithmetic_data_id', 'data')],)
def plot_ratevscumulativeprobabilisticaggregation(value, probabilisticvsarithmetic_data):
    return ratevscumulativeprobabilisticaggregation(dropdown_value=value,probabilisticvsarithmetic_data=probabilisticvsarithmetic_data)

@app_probabilisticvsarithmetic.callback(
    Output(component_id='ratevsdatearithmeticaggregation', component_property='figure'),
    [Input("probabilisticvsarithmetic_dropdown_id", "value"),Input('probabilisticvsarithmetic_data_id', 'data')],)
def plot_ratevsdatearithmeticaggregation(value, probabilisticvsarithmetic_data):
    return ratevsdatearithmeticaggregation(dropdown_value=value,probabilisticvsarithmetic_data=probabilisticvsarithmetic_data)

@app_probabilisticvsarithmetic.callback(
    Output(component_id='ratevscumulativearithmeticaggregation', component_property='figure'),
    [Input("probabilisticvsarithmetic_dropdown_id", "value"),Input('probabilisticvsarithmetic_data_id', 'data')],)
def plot_ratevscumulativearithmeticaggregation(value, probabilisticvsarithmetic_data):
    return ratevscumulativearithmeticaggregation(dropdown_value=value,probabilisticvsarithmetic_data=probabilisticvsarithmetic_data)
