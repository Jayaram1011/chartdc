import dash
import dash_bootstrap_components as dbc
from dash import ctx, dcc, html
from dash.dependencies import Input, Output, State
from django_plotly_dash import DjangoDash

from DCAssistChart.DashComponents.utils import get_otherphasesforecast_data
from DCAssistChart.PlotlyComponents.otherphasesforecast_plot import (
    gorvsdate, watercutvsdate, worvsdate)

config = {'modeBarButtonsToRemove': ['lasso2d', 'hoverClosestCartesian', 'hoverCompareCartesian', 'toggleSpikelines'], 'displaylogo': False, 'displayModeBar': True}

app_otherphasesforecast = DjangoDash("otherphasesforecast", add_bootstrap_links=True)

app_otherphasesforecast.layout = html.Div([
                
        dbc.Col([
            html.Br(),
            html.H5('Unique ID'),
        ], style={'textAlign': 'center'}),

        html.Br(),  

        dcc.Store(id='otherphasesforecast_data_id', storage_type='memory'),

        dbc.Col([
            dcc.Dropdown(id='otherphasesforecast_dropdown_id',
                    options=[],
                    placeholder="Select",
                    style={'fontSize': "15px", 'textAlign': 'center'}),
            ], lg=8, className ="mw-100"), 
        html.Br(),
        dbc.Col([
	        html.P('This plot window shows forecast of other phases in ratio terms for the selected wells.',style={'fontSize': "17px", 'textAlign': 'center','color':'black','background-color': '#FFFF00'}), 
	        html.P('Note: In case of no forecast only History will be shown.',style={'fontSize': "17px", 'textAlign': 'center','color':'black','background-color': '#FFFF00'}),

         ],className ="mw-100 text-info"),
        dbc.Col([
                dcc.Link('Click for all cases',id='allcases_link_id',href='#',style={'width': '100%', 'display': 'inline-block','text-align': 'right'}),
                ],className ="mw-100 text-info"),

        dbc.Row([ 
                dcc.Loading(
                     id="loading-1",
                        type="circle",
                        children= [ 
                                    dcc.Graph(id='gorvsdate',config=config, style={'width': '50%','display': 'inline-block'}),
                                    dcc.Graph(id='worvsdate',config=config, style={'width': '50%','display': 'inline-block'}),

                                    ],
                    ),
                 dcc.Loading(
                       id="loading-2",
                          type="circle",
                          children=[
                                      dcc.Graph(id='watercutvsdate',config=config, style={'width': '100%','display': 'inline-block'}),
                                      ],
                          ),
        ]),
            html.Br(),
     ])

@app_otherphasesforecast.callback(
        Output('otherphasesforecast_dropdown_id','options'),Output('otherphasesforecast_data_id','data'),Output('allcases_link_id', 'href'),
        Input('otherphasesforecast_data_id','data')
        )

def dropdown_options(data, session_state=None): 
        otherphasesforecast_data = get_otherphasesforecast_data(session_state['userid'], session_state['assetdb'], session_state['system'],session_state['allcases'])

        if len(otherphasesforecast_data.get('uniqueids')) != 0:
            options = [{'label': i, 'value': i} for i in otherphasesforecast_data.get('uniqueids').keys()]
        
        else:
            options = []

        if otherphasesforecast_data['system'] == 'true':   
            return options,otherphasesforecast_data,f'/chart/otherphasesforecastallcases/?userId={otherphasesforecast_data["userid"]}&system=true'
        else:
            return options,otherphasesforecast_data,f'/chart/otherphasesforecastallcases/?userId={otherphasesforecast_data["userid"]}'


@app_otherphasesforecast.callback(
    Output(component_id='gorvsdate', component_property='figure'),
    [Input("otherphasesforecast_dropdown_id", "value"),Input('otherphasesforecast_data_id', 'data')],)
def plot_gorvsdate(value, otherphasesforecast_data,session_state=None):
        return gorvsdate(dropdown_value=value, otherphasesforecast_data=otherphasesforecast_data)

@app_otherphasesforecast.callback(
    Output(component_id='worvsdate', component_property='figure'),
    [Input("otherphasesforecast_dropdown_id", "value"),Input('otherphasesforecast_data_id', 'data')],)
def plot_worvsdate(value, otherphasesforecast_data):
    return worvsdate(dropdown_value=value,otherphasesforecast_data=otherphasesforecast_data)

@app_otherphasesforecast.callback(
    Output(component_id='watercutvsdate', component_property='figure'),
    [Input("otherphasesforecast_dropdown_id", "value"),Input('otherphasesforecast_data_id', 'data')],)
def plot_watercutvsdate(value, otherphasesforecast_data):
    return watercutvsdate(dropdown_value=value,otherphasesforecast_data=otherphasesforecast_data)
