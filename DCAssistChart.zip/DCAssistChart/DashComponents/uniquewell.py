import dash
import dash_bootstrap_components as dbc
from dash import ctx, dcc, html
from dash.dependencies import Input, Output, State
from django_plotly_dash import DjangoDash

from DCAssistChart.DashComponents.utils import (
    get_outliers_data, get_wells_data, reset_outlier_data, select_box_data,
    update_selected_dates_decline_period, update_selected_outlier_data)
from DCAssistChart.PlotlyComponents.uniquewell_plot import ratevsdatevscum

config = {'modeBarButtonsToRemove': ['lasso2d', 'hoverClosestCartesian', 'hoverCompareCartesian', 'toggleSpikelines'], 'displaylogo': False, 'displayModeBar': True}

app_uniquewell = DjangoDash("uniquewell", add_bootstrap_links=True)

app_uniquewell.layout = html.Div([

        dbc.Modal(
            [
                dbc.ModalHeader(
                    dbc.ModalTitle("Dismissing"), close_button=False
                ),
                dbc.ModalBody(id="modal-body-id"
                ),
                dbc.ModalFooter(dbc.Button("Close", id="close-dismiss")),
            ],
            id="modal-dismiss",
            keyboard=False,
            backdrop="static",
        ),
        dbc.Col([
            html.Br(),
            html.H5('Unique ID'),
        ], style={'textAlign': 'center'}),

        html.Br(),  

        dcc.Store(id='uniquewell_data_id', storage_type='memory'),
        dcc.Store(id='uniquewell_selected_data_id', storage_type='memory'),
        dcc.Store(id='uniquewell_outlier_data_id', storage_type='memory'),

        dbc.Col([
            dcc.Dropdown(id='uniquewell_dropdown_id',
                    options=[],
                    placeholder="Select Uniqwell",
                    style={'fontSize': "15px", 'textAlign': 'center'}),
            ], lg=8, className ="mw-100"), 
        html.Br(),
        dbc.Col([
        html.P('This plot window shows forecast rates and forecast parameter values for different forecast cases for selected wells.',style={'fontSize': "17px", 'textAlign': 'center', 'background-color': '#FFFF00'}),
        html.P('Enlarge the Rate vs Date and Rate vs Cumulative Volume to see comparison with the benchmark case.',style={'fontSize': "17px", 'textAlign': 'center','background-color': '#FFFF00'}),
        ],className ="mw-100 text-info"),

        dbc.Row([
                    dcc.Loading(
                        id="loading-1",
                        type="circle",
                        children= [dcc.Graph(id='ratevsdate', config=config, style={'width': '100%','display': 'inline-block'}), 
                                    # dcc.Graph(id='ratevscum', config=config, style={'width': '50%','display': 'inline-block'})
                                    ],
                        )
        ]),
        html.Br(),
        html.Div(id='display'),
        dbc.Button("Reset", id="submit-val1", n_clicks=0, style={'display':'none'}),
        dbc.Button("Outlier", id="submit-val2", n_clicks=0, style={'display':'none'}),
        dbc.Button("Update Decline Period", id="submit-val3", n_clicks=0, style={'display':'none'}),
    ],className="container-fluid")


@app_uniquewell.callback(
    Output('uniquewell_dropdown_id','options'),Output('uniquewell_data_id','data'),
    Input('uniquewell_data_id','data')
)
def dropdown_options(data, session_state=None):
    uniquewell_data = get_wells_data(session_state['userid'], session_state['assetdb'], session_state['system'])

    if len(uniquewell_data.get('uniqueids')) != 0:
        options = [{'label': i, 'value': i} for i in uniquewell_data.get('uniqueids').keys()]
    else:
        options = []

    return options, uniquewell_data
    
#pylint: ignore=unused-argument
@app_uniquewell.callback(
    Output('uniquewell_outlier_data_id','data'), Output(component_id='ratevsdate', component_property='figure'),
    [Input('uniquewell_dropdown_id', 'value'), Input('uniquewell_data_id', 'data')],
    State('uniquewell_outlier_data_id','data'))
def plot_ratevsdate(value, uniquewell_data, session_state=None):
    outlier_data =  get_outliers_data(assetdb = uniquewell_data['assetdb'], userid=uniquewell_data['userid'])
    return outlier_data, ratevsdatevscum(dropdown_value=value,uniquewell_data=uniquewell_data,outlier_data=outlier_data)

app_uniquewell.clientside_callback(
    """        
        function(figure, uniquewell_data) {
            doc = window.frames.document;

            console.log(doc.body.textContent.indexOf("Decline-Period"))

            if(doc.body.textContent.indexOf("Decline-Period")!==-1){
                console.log("PD Well")

                d = doc.querySelector("div.modebar-container div");
        
                dd = doc.createElement("div");
                
                dd.className = "modebar-group";
        
                if (!doc.getElementById("reset-icon")) {
                    a1 = doc.createElement("a");
                    a1.rel = "tooltip";
                    a1.id = "reset-icon"
                    a1.className = "modebar-btn";
                    a1.setAttribute('data-title', 'Reset');
        
                    img1 = doc.createElement("img");
                    img1.src = "https://" + uniquewell_data["domain"] + "/reset.svg";
        
                    a1.appendChild(img1);
        
                    dd.appendChild(a1);
        
                    d.appendChild(dd);

                    a1.onclick = function () { window.frames.document.getElementById("submit-val1").click()}
                };
        
                if (!doc.getElementById("delete-icon")) {
                    a2 = doc.createElement("a");
                    a2.rel = "tooltip";
                    a2.id = "delete-icon"
                    a2.className = "modebar-btn";
                    a2.setAttribute('data-title', 'Outlier');
        
                    img2 = doc.createElement("img");
                    img2.src = "https://" + uniquewell_data["domain"] + "/remove.svg";
        
                    a2.appendChild(img2);
        
                    dd.appendChild(a2);
        
                    d.appendChild(dd);

                    a2.onclick = function () { window.frames.document.getElementById("submit-val2").click()}
                };
        
        	    if (!doc.getElementById("update-period-icon")) {
                    a3 = doc.createElement("a");
                    a3.rel = "tooltip";
                    a3.id = "update-period-icon"
                    a3.className = "modebar-btn";
                    a3.setAttribute('data-title', 'Update Decline Period');
        
                    img3 = doc.createElement("img");
                    img3.src = "https://" + uniquewell_data["domain"] + "/update_decline_period.svg";
        
                    a3.appendChild(img3);
        
                    dd.appendChild(a3);
        
                    d.appendChild(dd);

                    a3.onclick = function () { window.frames.document.getElementById("submit-val3").click()}
                };
            };

        return window.dash_clientside.no_update;
        }
    """,
    Output('ratevsdate', 'id'),
    Input('ratevsdate', 'figure'), Input('uniquewell_data_id', 'data')
)


@app_uniquewell.callback(
    Output('uniquewell_selected_data_id','data'),
    [Input('ratevsdate','selectedData'),Input('uniquewell_dropdown_id', 'value'), 
    Input('uniquewell_data_id', 'data')])
def select_data(selectedData, value, uniquewell_data):
    return select_box_data(selectedData, value, uniquewell_data, 'Rate')

@app_uniquewell.callback(
    Output("modal-dismiss", "is_open"),Output("modal-body-id", "children"),
    Output("close-dismiss", "n_clicks"),Output('uniquewell_selected_data_id','clear_data'),Output('uniquewell_dropdown_id','value'),
    Input("submit-val1", "n_clicks"),Input("submit-val2", "n_clicks"), Input("submit-val3", "n_clicks"),
    Input("close-dismiss", "n_clicks"),Input('uniquewell_dropdown_id', 'value'),
    [State('uniquewell_selected_data_id', 'data'),State("uniquewell_data_id","data"),State('uniquewell_outlier_data_id','data'), State("modal-dismiss", "is_open")],
    prevent_initial_call=True
)
def toggle_modal(n_open_reset, n_open_outlier, n_open_decline, n_close, value, uniquewell_selected_data, uniquewell_data, uniquewell_outlier_data, is_open):

    ctx = dash.callback_context

    if ctx.triggered[0]['prop_id'].split('.')[0] == "submit-val1":
        n_open = n_open_reset
        uniquewell_selected_data["selected_dates"] = True
    elif ctx.triggered[0]['prop_id'].split('.')[0] == "submit-val2":
        n_open = n_open_outlier
    elif ctx.triggered[0]['prop_id'].split('.')[0] == "submit-val3":
        n_open = n_open_decline
    else:
        n_open = 0

    if uniquewell_selected_data:
        if (uniquewell_selected_data["selected_dates"] and n_open) or n_close:

            if n_close:                    
                return not is_open , dash.no_update, 0, True, value
            else:
                if ctx.triggered[0]['prop_id'].split('.')[0] == "submit-val1":
                    msg = reset_outlier_data(uniqueid = value, asset_db = uniquewell_data['assetdb'], user_id = uniquewell_data['userid'])

                elif ctx.triggered[0]['prop_id'].split('.')[0] == "submit-val2":
                    msg = update_selected_outlier_data(uniqueid = value, asset_db = uniquewell_selected_data['assetdb'], user_id = uniquewell_selected_data['user_id'], selected_date_list = uniquewell_selected_data['selected_dates'], selected_column = uniquewell_selected_data['selected_column'])

                elif ctx.triggered[0]['prop_id'].split('.')[0] == "submit-val3":
                    msg = update_selected_dates_decline_period(uniqueid = value, asset_db = uniquewell_selected_data['assetdb'], user_id = uniquewell_selected_data['user_id'], selected_date_list = uniquewell_selected_data['selected_dates'])

                return not is_open , msg, 0, False, dash.no_update

    else:
        if n_open or n_close:
            msg = "Select Date using box-select"
            return not is_open , msg, 0, dash.no_update, dash.no_update
        return is_open, dash.no_update, 0, dash.no_update, dash.no_update



 