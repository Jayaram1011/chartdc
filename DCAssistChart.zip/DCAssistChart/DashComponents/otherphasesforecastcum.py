import dash
import dash_bootstrap_components as dbc
from dash import ctx, dcc, html
from dash.dependencies import Input, Output, State
from django_plotly_dash import DjangoDash

from DCAssistChart.DashComponents.utils import get_otherphasesforecastcum_data
from DCAssistChart.PlotlyComponents.otherphasesforecastcum_plot import (
    gorvscumulativevolume, watercutvscumulativevolume, worvscumulativevolume)

config = {'modeBarButtonsToRemove': ['lasso2d', 'hoverClosestCartesian', 'hoverCompareCartesian', 'toggleSpikelines'], 'displaylogo': False, 'displayModeBar': True}

app_otherphasesforecastcum = DjangoDash("otherphasesforecastcum", add_bootstrap_links=True)

app_otherphasesforecastcum.layout = html.Div([
                
        dbc.Col([
            html.Br(),
            html.H5('Unique ID'),
        ], style={'textAlign': 'center'}),

        html.Br(),  

        dcc.Store(id='otherphasesforecastcum_data_id', storage_type='memory'),

        dbc.Col([
            dcc.Dropdown(id='otherphasesforecastcum_dropdown_id',
                    options=[],
                    placeholder="Select",
                    style={'fontSize': "15px", 'textAlign': 'center'}),
            ], lg=8, className ="mw-100"), 
        html.Br(),
        dbc.Col([
	        html.P('This plot window shows forecast of other phases in ratio terms for the selected wells.',style={'fontSize': "17px", 'textAlign': 'center','color':'black','background-color': '#FFFF00'}), 
	        html.P('Note: In case of no forecast only History will be shown.',style={'fontSize': "17px", 'textAlign': 'center','color':'black','background-color': '#FFFF00'}),

         ],className ="mw-100 text-info"),
        dbc.Col([
                dcc.Link('Click for all cases',id='allcases_link_id',href='#',style={'width': '100%', 'display': 'inline-block','text-align': 'right'}),
                ],className ="mw-100 text-info"),

        dbc.Row([ 
                dcc.Loading(
                     id="loading-1",
                        type="circle",
                        children= [ 
                                    dcc.Graph(id='gorvscumulativevolume',config=config, style={'width': '50%','display': 'inline-block'}),
                                    dcc.Graph(id='worvscumulativevolume',config=config, style={'width': '50%','display': 'inline-block'}),

                                    ],
                    ),
                 dcc.Loading(
                       id="loading-2",
                          type="circle",
                          children=[
                                      dcc.Graph(id='watercutvscumulativevolume',config=config, style={'width': '100%','display': 'inline-block'}),
                                      ],
                          ),
        ]),
            html.Br(),
     ])

@app_otherphasesforecastcum.callback(
        Output('otherphasesforecastcum_dropdown_id','options'),Output('otherphasesforecastcum_data_id','data'),Output('allcases_link_id', 'href'),
        Input('otherphasesforecastcum_data_id','data')
        )
def dropdown_options(data, session_state=None): 
    otherphasesforecastcum_data = get_otherphasesforecastcum_data(session_state['userid'], session_state['assetdb'], session_state['system'],session_state['allcases'])

    if len(otherphasesforecastcum_data.get('uniqueids')) != 0:
            options = [{'label': i, 'value': i} for i in otherphasesforecastcum_data.get('uniqueids').keys()]
        
    else:
            options = []

    if otherphasesforecastcum_data['system'] == 'true':   
        return options,otherphasesforecastcum_data,f'/chart/otherphasesforecastcumallcases/?userId={otherphasesforecastcum_data["userid"]}&system=true'
    else:
        return options,otherphasesforecastcum_data,f'/chart/otherphasesforecastcumallcases/?userId={otherphasesforecastcum_data["userid"]}'
   
@app_otherphasesforecastcum.callback(
    Output(component_id='gorvscumulativevolume', component_property='figure'),
    [Input("otherphasesforecastcum_dropdown_id", "value"),Input('otherphasesforecastcum_data_id', 'data')],)
def plot_gorvscumulativevolume(value, otherphasesforecastcum_data,session_state=None):
        return gorvscumulativevolume(dropdown_value=value, otherphasesforecastcum_data=otherphasesforecastcum_data)

@app_otherphasesforecastcum.callback(
    Output(component_id='worvscumulativevolume', component_property='figure'),
    [Input("otherphasesforecastcum_dropdown_id", "value"),Input('otherphasesforecastcum_data_id', 'data')],)
def plot_worvscumulativevolume(value, otherphasesforecastcum_data):
    return worvscumulativevolume(dropdown_value=value,otherphasesforecastcum_data=otherphasesforecastcum_data)

@app_otherphasesforecastcum.callback(
    Output(component_id='watercutvscumulativevolume', component_property='figure'),
    [Input("otherphasesforecastcum_dropdown_id", "value"),Input('otherphasesforecastcum_data_id', 'data')],)
def plot_watercutvscumulativevolume(value, otherphasesforecastcum_data):
    return watercutvscumulativevolume(dropdown_value=value,otherphasesforecastcum_data=otherphasesforecastcum_data)
