from DCAssistChart.PlotlyComponents.plot_figures.probabilisticvsarithmetic_plot_figure import (
    get_data_not_found_fig, probabilisticvsarithmetic_plot_figure)
from DCAssistChart.PlotlyComponents.utils.df_queries import (
    get_filtered_df, get_integrated_output_df, rename_columncontent_df)
from DCAssistChart.PlotlyComponents.utils.helper import get_file_path
from DCAssistChart.PlotlyComponents.utils.ploty_constant import (
    INTEGRATED_OUTPUT_CSV, INTEGRATED_OUTPUT_FULL_CSV,
    P_CASE_WELL_LEVEL_ALLCASES, PROBABILISTICVSARITHMETIC)
from runalgorithm.helper import get_run_dir


def ratevsdateprobabilisticaggregation(dropdown_value,probabilisticvsarithmetic_data):
    if dropdown_value in probabilisticvsarithmetic_data['uniqueids']:
        runid, well_type = probabilisticvsarithmetic_data['uniqueids'][dropdown_value].split(',') 
        file_name = INTEGRATED_OUTPUT_CSV
        if probabilisticvsarithmetic_data["allcases"] == True:
            file_name = INTEGRATED_OUTPUT_FULL_CSV

        path = get_run_dir(probabilisticvsarithmetic_data['assetdb'], runid)
        integrated_output_path = get_file_path(path,file_name)
        df = get_integrated_output_df(integrated_output_path, PROBABILISTICVSARITHMETIC['ratevsdateprobabilisticaggregation']['use_colunms'])
        df = rename_columncontent_df(df)

        p_case_well_levels_list = PROBABILISTICVSARITHMETIC['ratevsdateprobabilisticaggregation']['PCase_well_filter']
        if probabilisticvsarithmetic_data["allcases"] == True:
            p_case_well_levels_list = P_CASE_WELL_LEVEL_ALLCASES

        df_p_case_well_levels_list = []

        for index, value in enumerate(p_case_well_levels_list):
            p_case_and_uniqueid_filter_df = get_filtered_df(df, dropdown_value, _filters = [p_case_well_levels_list[index]])
            df_p_case_well_levels_list.append(p_case_and_uniqueid_filter_df)
        
        df_history = get_filtered_df(df, dropdown_value, _filters = ['History'])
    
        fig = probabilisticvsarithmetic_plot_figure(p_case_well_levels_list, df_p_case_well_levels_list,plot_name='ratevsdateprobabilisticaggregation')
    
        return fig
        
    else:
        return get_data_not_found_fig(title= PROBABILISTICVSARITHMETIC['ratevsdateprobabilisticaggregation']['title'])

def ratevscumulativeprobabilisticaggregation(dropdown_value,probabilisticvsarithmetic_data):
    if dropdown_value in probabilisticvsarithmetic_data['uniqueids']:
        runid, well_type = probabilisticvsarithmetic_data['uniqueids'][dropdown_value].split(',') 
        file_name = INTEGRATED_OUTPUT_CSV
        if probabilisticvsarithmetic_data["allcases"] == True:
            file_name = INTEGRATED_OUTPUT_FULL_CSV

        path = get_run_dir(probabilisticvsarithmetic_data['assetdb'], runid)
        integrated_output_path = get_file_path(path,file_name)
        df = get_integrated_output_df(integrated_output_path, PROBABILISTICVSARITHMETIC['ratevscumulativeprobabilisticaggregation']['use_colunms'])
        df = rename_columncontent_df(df)

        p_case_well_levels_list = PROBABILISTICVSARITHMETIC['ratevscumulativeprobabilisticaggregation']['PCase_well_filter']
        if probabilisticvsarithmetic_data["allcases"] == True:
            p_case_well_levels_list = P_CASE_WELL_LEVEL_ALLCASES

        df_p_case_well_levels_list = []

        for index, value in enumerate(p_case_well_levels_list):
            p_case_and_uniqueid_filter_df = get_filtered_df(df, dropdown_value, _filters = [p_case_well_levels_list[index]])
            df_p_case_well_levels_list.append(p_case_and_uniqueid_filter_df)
       
        df_history = get_filtered_df(df, dropdown_value, _filters = ['History'])
    
        fig = probabilisticvsarithmetic_plot_figure(p_case_well_levels_list, df_p_case_well_levels_list,plot_name='ratevscumulativeprobabilisticaggregation')
    
        return fig
        
    else:
        return get_data_not_found_fig(title= PROBABILISTICVSARITHMETIC['ratevscumulativeprobabilisticaggregation']['title'])

def ratevsdatearithmeticaggregation(dropdown_value,probabilisticvsarithmetic_data):
    if dropdown_value in probabilisticvsarithmetic_data['uniqueids']:
        runid, well_type = probabilisticvsarithmetic_data['uniqueids'][dropdown_value].split(',') 
        file_name = INTEGRATED_OUTPUT_CSV
        if probabilisticvsarithmetic_data["allcases"] == True:
            file_name = INTEGRATED_OUTPUT_FULL_CSV

        path = get_run_dir(probabilisticvsarithmetic_data['assetdb'], runid)
        integrated_output_path = get_file_path(path,file_name)
        df = get_integrated_output_df(integrated_output_path, PROBABILISTICVSARITHMETIC['ratevsdatearithmeticaggregation']['use_colunms'])
        df = rename_columncontent_df(df)

        p_case_well_levels_list = PROBABILISTICVSARITHMETIC['ratevsdatearithmeticaggregation']['PCase_well_filter']
        if probabilisticvsarithmetic_data["allcases"] == True:
            p_case_well_levels_list = P_CASE_WELL_LEVEL_ALLCASES

        df_p_case_well_levels_list = []

        for index, value in enumerate(p_case_well_levels_list):
            p_case_and_uniqueid_filter_df = get_filtered_df(df, dropdown_value, _filters = [p_case_well_levels_list[index]])
            df_p_case_well_levels_list.append(p_case_and_uniqueid_filter_df)
       
        df_history = get_filtered_df(df, dropdown_value, _filters = ['History'])
    
        fig = probabilisticvsarithmetic_plot_figure(p_case_well_levels_list, df_p_case_well_levels_list,plot_name='ratevsdatearithmeticaggregation')
    
        return fig
        
    else:
        return get_data_not_found_fig(title= PROBABILISTICVSARITHMETIC['ratevsdatearithmeticaggregation']['title'])

def ratevscumulativearithmeticaggregation(dropdown_value,probabilisticvsarithmetic_data):
    if dropdown_value in probabilisticvsarithmetic_data['uniqueids']:
        runid, well_type = probabilisticvsarithmetic_data['uniqueids'][dropdown_value].split(',') 
        file_name = INTEGRATED_OUTPUT_CSV
        if probabilisticvsarithmetic_data["allcases"] == True:
            file_name = INTEGRATED_OUTPUT_FULL_CSV

        path = get_run_dir(probabilisticvsarithmetic_data['assetdb'], runid)
        integrated_output_path = get_file_path(path,file_name)
        df = get_integrated_output_df(integrated_output_path, PROBABILISTICVSARITHMETIC['ratevscumulativearithmeticaggregation']['use_colunms'])
        df = rename_columncontent_df(df)

        p_case_well_levels_list = PROBABILISTICVSARITHMETIC['ratevscumulativearithmeticaggregation']['PCase_well_filter']
        if probabilisticvsarithmetic_data["allcases"] == True:
            p_case_well_levels_list = P_CASE_WELL_LEVEL_ALLCASES

        df_p_case_well_levels_list = []

        for index, value in enumerate(p_case_well_levels_list):
            p_case_and_uniqueid_filter_df = get_filtered_df(df, dropdown_value, _filters = [p_case_well_levels_list[index]])
            df_p_case_well_levels_list.append(p_case_and_uniqueid_filter_df)
        
        df_history = get_filtered_df(df, dropdown_value, _filters = ['History'])
    
        fig = probabilisticvsarithmetic_plot_figure(p_case_well_levels_list, df_p_case_well_levels_list,plot_name='ratevscumulativearithmeticaggregation')
    
        return fig
        
    else:
        return get_data_not_found_fig(title= PROBABILISTICVSARITHMETIC['ratevscumulativearithmeticaggregation']['title'])
