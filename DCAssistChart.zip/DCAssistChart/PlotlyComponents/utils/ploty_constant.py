INTEGRATED_OUTPUT_CSV = "integrated_output.csv"
INTEGRATED_OUTPUT_FULL_CSV = "integrated_output_full.csv"

P_CASE_WELL_LEVEL_ALLCASES = ['P05', 'P10', 'P15', 'P25', 'P40', 'P50', 'P60', 'P75', 'P85', 'P90', 'P95']


COLOR_MAPPING_DICT = {
                        "P05": "#fa8072",
                        "P10": "#8D42E1",   
                        "P15": "#ccac00",
                        "P25": "#9acd32",
                        "P40": "#e07719",
                        "P50": "#4CCF2F",
                        "P60": "#00ffff",
                        "P75": "#7a49a5",
                        "P85": "#d59890",
                        "P90": "#FA1C0E",
                        "P95": "#a3ffb4",
                        "History": "#080808",
                        "Decline_Period": "#6c1e2e",
                        "Used_Outlier": "#ff0000",
                        "Selected_Outlier": "#ff69B4"}


UNIQUEWELL = {
    'ratevsdate':{
        'legend_title' : 'Well Cases',
        'title': 'Rate vs Date',
        'x_axis_dfcol' : 'Date',
        'y_axis_dfcol' : 'Rate',
        'y2_axis_dfcol': 'Decline_Period',
        'x_axis_title' : 'Date',
        'y_axis_title' : 'Rate',
        'y2_axis_title' : 'Decline-Period',
    },
    'ratevscum' :{
        'title': 'Rate vs Cum',
        'x_axis_title': 'Cum',
        'y_axis_title': 'Rate',
    },
    'use_colunms': ['Case_well_level', 'Date', 'Rate', 'UNIQUEID', 'Cumulative', 'Decline_Period'],
    'use_colunms_outlier_history' : ['Case_well_level', 'Date', 'Rate', 'UNIQUEID', 'Cumulative'],
    'PCase_well_filter' : ['P10','P50','P90'],
    'cases' : ['P10','P50','P90']
}
OTHERPHASEFORECAST = {
    'gorvsdate':{
        'legend_title' : 'Well Cases',
        'title': 'GOR vs Date',
        'x_axis_dfcol' : 'Date',
        'y_axis_dfcol' : 'GOR',
        'x_axis_title' : 'Date',
        'y_axis_title' : 'GOR(E3scf/bbl)',
        
        'use_colunms': ['Case_well_level','UNIQUEID','Date','GOR','Rate','Cumulative'],
        'PCase_well_filter' : ['P10','P50','P90','History'],
        
    },

    'worvsdate' :{
        'legend_title' : 'Well Cases',
        'title': 'WOR vs Date',
        'x_axis_dfcol' : 'Date',
        'y_axis_dfcol' : 'WOR',
        'x_axis_title': 'Date',
        'y_axis_title': 'WOR',
        
        'use_colunms':['Case_well_level','GOR','WOR','WC','Date', 'Rate', 'UNIQUEID', 'Cumulative'],
        'PCase_well_filter' : ['P10','P50','P90','History'],  
    },
    'watercutvsdate' :{
        'legend_title' : 'Well Cases',
        'title': 'Water Cut vs Date',
        'x_axis_dfcol' : 'Date',
        'y_axis_dfcol' : 'WC',
        'x_axis_title': 'Date',
        'y_axis_title': 'Water Cut',
        
        'use_colunms':['GOR','WOR','WC','Case_well_level', 'Date', 'Rate', 'UNIQUEID', 'Cumulative'],
        'PCase_well_filter' : ['P10','P50','P90','History'],
    },
}
OTHERPHASEFORECASTCUM = {
    
    'gorvscumulativevolume':{
        'legend_title' : 'Well Cases',
        'title': 'GOR vs Cumulative Volume',
        'x_axis_dfcol' : 'Cumulative',
        'y_axis_dfcol' : 'GOR',
        'x_axis_title' : 'Cumulative Volume',
        'y_axis_title' : 'GOR',
        
        'use_colunms': ['Case_well_level', 'Date','GOR','UNIQUEID', 'Cumulative'],
        'PCase_well_filter' : ['P10','P50','P90','History'],
    },
    'worvscumulativevolume' :{
        'legend_title' : 'Well Cases',
        'title': 'WOR vs Cumulative Volume',
        'x_axis_dfcol' : 'Cumulative',
        'y_axis_dfcol' : 'WOR',
        'x_axis_title': 'Cumulative Volume',
        'y_axis_title': 'WOR', 
        
        'use_colunms': ['GOR','WOR','WC','Case_well_level', 'Date', 'Rate', 'UNIQUEID', 'Cumulative'],
        'PCase_well_filter' : ['P10','P50','P90','History'], 
    },
    'watercutvscumulativevolume' :{
        'legend_title' : 'Well Cases',
        'title': 'Water Cut vs Cumulative Volume',
        'x_axis_dfcol' : 'Cumulative',
        'y_axis_dfcol' : 'WC',
        'x_axis_title': 'Cumulative Volume',
        'y_axis_title': 'Water Cut',
        
        'use_colunms': ['GOR','WOR','WC','Case_well_level', 'Date', 'Rate', 'UNIQUEID', 'Cumulative'],
        'PCase_well_filter' : ['P10','P50','P90','History'],
    },
}
PROBABILISTICVSARITHMETIC = {
    
    'ratevsdateprobabilisticaggregation':{
        'legend_title' : 'Well Cases',
        'title': 'Rate vs Date Probabilistic Aggregation',
        'x_axis_dfcol' : 'Date',
        'y_axis_dfcol' : 'Rate',
        'x_axis_title' : 'Date',
        'y_axis_title' : 'Rate(mbb/day)',
        
        'use_colunms': ['Case_well_level', 'Date', 'Rate', 'UNIQUEID', 'Cumulative'],
        'PCase_well_filter' : ['P10','P50','P90','History'],
},
    'ratevscumulativeprobabilisticaggregation' :{
        'legend_title' : 'Well Cases',
        'title': 'Rate vs Cumulative Probabilistic Aggregation',
        'x_axis_dfcol' : 'Cumulative',
        'y_axis_dfcol' : 'Rate',
        'x_axis_title': 'Cumulative',
        'y_axis_title': 'Rate(mbb/day)',  
        
        'use_colunms': ['Case_well_level', 'Date', 'Rate', 'UNIQUEID', 'Cumulative'],
        'PCase_well_filter' : ['P10','P50','P90','History'],
},
    'ratevsdatearithmeticaggregation' :{
        'legend_title' : 'Well Cases',
        'title': 'Rate vs Date Arithmetic Aggregation',
        'x_axis_dfcol' : 'Date',
        'y_axis_dfcol' : 'Rate',
        'x_axis_title' : 'Date',
        'y_axis_title' : 'Rate(mbb/day)',
        'use_colunms': ['Case_well_level', 'Date', 'Rate', 'UNIQUEID', 'Cumulative'],
        'PCase_well_filter' : ['P10','P50','P90','History'],
},

    'ratevscumulativearithmeticaggregation' :{
        'legend_title' : 'Well Cases',
        'title': 'Rate vs Cumulative Arithmetic Aggregation',
        'x_axis_dfcol' : 'Cumulative',
        'y_axis_dfcol' : 'Rate',
        'x_axis_title': 'Cumulative',
        'y_axis_title': 'Rate(mbb/day)',
        
        'use_colunms': ['Case_well_level', 'Date', 'Rate', 'UNIQUEID', 'Cumulative'],
        'PCase_well_filter' : ['P10','P50','P90','History'],
},

}