import logging

import pandas as pd

from DCAssistChart.PlotlyComponents.utils.helper import file_exist

logger = logging.getLogger(__name__)

def get_df_colmn_parse_by_date(file_path, usecols):
    return pd.read_csv(file_path, parse_dates=['Date'], usecols=usecols)

def get_integrated_output_df(path, use_colunms):
    try:
        df = pd.DataFrame()
        if file_exist(path):
            df = get_df_colmn_parse_by_date(path, use_colunms)
        return df
    except Exception as e:
        logger.error(e, exc_info=True)

def get_filtered_df(df, uniqueid, _filters):
    df = df[df['Case_well_level'].isin(_filters)]
    filtered_df = df[df.UNIQUEID == uniqueid]
    return filtered_df

def get_filtered_df_multiple_dropdown(df, col_name, _filters):
    df = df[df[col_name].isin(_filters)]
    return df

def rename_columncontent_df(df):
    df['Case_well_level'] = df['Case_well_level'].str.replace('P5_well_level_indx', 'P05_well_level_indx').str.replace('_well_level_indx', '')
    return df

def get_outlier_history_df(path, use_colunms):
    df = pd.DataFrame()
    if file_exist(path):
        df = get_df_colmn_parse_by_date(path, use_colunms)
        return df[df.Case_well_level == 'History']
    return df

def empty_df():
    df = pd.DataFrame()
    return df

def di_calc_update(df):
    df['Di'] = df['Di'].fillna(0)
    df['Di'] = df['Di'] * 100
    df['Di'] = df['Di'].round(2)
    df = df[['Case_well_level', 'Di', 'UNIQUEID']].drop_duplicates()
    return df

def b_calc_update(df):
    df['b'] = df['b'].fillna(0)
    df['b'] = df['b'].round(2)
    df = df[['Case_well_level', 'b', 'UNIQUEID']].drop_duplicates()
    return df

def dropna_df(df, col_name):
    return df.dropna(subset=[col_name],inplace=False)

def groupbysum_df(df, col_list):
    return df.groupby(col_list).sum().reset_index()

def sort_df(df, col_name):
    return df.sort_values(by=col_name)

def dict_to_df(dict_name):
    return pd.DataFrame.from_dict(dict_name)

def list_unique_string_in_col(df, col_name, string_startwith):
    return [x for x in df[col_name].unique() if x.startswith(string_startwith)]

def start_to_end_dates_df(df, startdate, enddate):
    if startdate != None and enddate != None:
        enddate = pd.to_datetime(enddate) + pd.offsets.MonthEnd()
        mask = (df['Date'] > startdate) & (df['Date'] <= enddate)
        df = df.loc[mask]
    elif startdate != None and enddate == None:
        mask = (df['Date'] > startdate)
        df = df.loc[mask]
    elif startdate == None and enddate != None:
        enddate = pd.to_datetime(enddate) + pd.offsets.MonthEnd()
        mask = (df['Date'] <= enddate)
        df = df.loc[mask]
    elif startdate == None and enddate == None:
        df = df
    return df

