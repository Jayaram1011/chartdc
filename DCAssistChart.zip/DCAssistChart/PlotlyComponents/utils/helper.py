import os 

def get_file_path(path, file_name):
    return os.path.join(path,file_name)

def file_exist(file_path):
    return os.path.exists(file_path)