from DCAssistChart.PlotlyComponents.plot_figures.plot_figures_utils import line_plot, scatter_plot, graph_layout, get_fig_with_line_plot, add_yaxis2_layout
from DCAssistChart.PlotlyComponents.utils.ploty_constant import  COLOR_MAPPING_DICT, UNIQUEWELL

import plotly.graph_objects as go

import plotly.express as px
import pandas as pd

def uniquewell_plot_figure(df_P10,df_P50,df_P90,df_history,df_decline_period,well_type, df_selected_outlier, df_used_outlier):

    data = []

    if not df_P10.empty:
        trace_P10 = scatter_plot(data_frame = df_P10, x=UNIQUEWELL['ratevsdate']['x_axis_dfcol'], y=UNIQUEWELL['ratevsdate']['y_axis_dfcol'], color=COLOR_MAPPING_DICT['P10'], name = 'P10')
        data.append(trace_P10)

    if not df_P50.empty:
        trace_P50 = scatter_plot(data_frame = df_P50, x=UNIQUEWELL['ratevsdate']['x_axis_dfcol'], y=UNIQUEWELL['ratevsdate']['y_axis_dfcol'], color=COLOR_MAPPING_DICT['P50'], name = 'P50')
        data.append(trace_P50)

    if not df_P90.empty:
        trace_P90 = scatter_plot(data_frame = df_P90, x=UNIQUEWELL['ratevsdate']['x_axis_dfcol'], y=UNIQUEWELL['ratevsdate']['y_axis_dfcol'], color=COLOR_MAPPING_DICT['P90'], name = 'P90')
        data.append(trace_P90)
    
    if not df_history.empty:
        trace_history = scatter_plot(data_frame=df_history,x=UNIQUEWELL['ratevsdate']['x_axis_dfcol'], y=UNIQUEWELL['ratevsdate']['y_axis_dfcol'],color=COLOR_MAPPING_DICT['History'],name="History",mode='markers')
        data.append(trace_history)
        
    if not df_selected_outlier.empty:
        trace_history = scatter_plot(data_frame=df_selected_outlier,x=UNIQUEWELL['ratevsdate']['x_axis_dfcol'], y=UNIQUEWELL['ratevsdate']['y_axis_dfcol'],color=COLOR_MAPPING_DICT['Selected_Outlier'],name="Selected-Outlier",mode='markers')
        data.append(trace_history)

    if not df_used_outlier.empty:
        trace_history = scatter_plot(data_frame=df_used_outlier,x=UNIQUEWELL['ratevsdate']['x_axis_dfcol'], y=UNIQUEWELL['ratevsdate']['y_axis_dfcol'],color=COLOR_MAPPING_DICT['Used_Outlier'],name="Used-Outlier",mode='markers')
        data.append(trace_history)

    # data = [trace_P10, trace_P50, trace_P90, trace_history]

    layout = graph_layout(legend_title= UNIQUEWELL['ratevsdate']['legend_title'], title = UNIQUEWELL['ratevsdate']['title'], xaxis = UNIQUEWELL['ratevsdate']['x_axis_title'], yaxis = UNIQUEWELL['ratevsdate']['y_axis_title'])

    if well_type == 'PD':
        trace_decline_period = scatter_plot(data_frame = df_decline_period, x=UNIQUEWELL['ratevsdate']['x_axis_dfcol'], y=UNIQUEWELL['ratevsdate']['y2_axis_dfcol'], color=COLOR_MAPPING_DICT['Decline_Period'], name = 'Decline-Period', yaxis="y2")
        data.append(trace_decline_period)
        layout.yaxis2 = add_yaxis2_layout(title=UNIQUEWELL['ratevsdate']['y2_axis_title'])

    fig = go.Figure(data=data,layout=layout)

    return fig


def get_data_not_found_fig(title):
    fig = go.Figure()
    fig.update_layout(
            title_text=title,
            title=dict(x=0.5),
            xaxis =  { "visible": False },
            yaxis = { "visible": False },
            annotations = [
                {   
                    "text": "No data for given RUN name",
                    "showarrow": False,
                    "font": {
                        "size": 20
                    }
                }
            ]
        )
    return fig
