import plotly.express as px
import plotly.graph_objects as go


def line_plot( data_frame=None, x=None, y=None, color=None, color_discrete_map=None, category_orders=None):

    return px.line(data_frame = data_frame,
                x=x, y=y,
                color=color,
                color_discrete_map=color_discrete_map,
                category_orders = category_orders
            )

def scatter_plot(data_frame=None,x=None, y=None,color=None,name=None, mode="lines", yaxis=None):
    return go.Scatter(x=getattr(data_frame, x).tolist(),
            y=getattr(data_frame, y),
            name=name,
            mode=mode,
            marker_color=color,
            yaxis = yaxis
        )
def bar_plot(data_frame=None, x=None, y=None,color=None, name=None):
    return go.Bar(x = data_frame[x], y = data_frame[y], marker=dict(color = color), name=name, marker_line_width=0)

def bar_plot_barode_group(x=None, y=None,color=None, name=None):
    return go.Bar(x = x, y=y, marker=dict(color = color), name=name)

def graph_layout(legend_title=None, title = None, xaxis = None, yaxis = None, barmode = None):
    return go.Layout(
                legend=dict( x=1.1, y=1.15, title_font_family="Times New Roman",
                        font=dict(size=11, color="black"),
                ),
                legend_title = legend_title,
                title = {'text': title, 'x':0.5,'xanchor': 'center', 'yanchor': 'top'},
                xaxis = {'title': xaxis},
                yaxis = {'title': yaxis},
                plot_bgcolor="#E8E8E8",
                height=500,
                newshape_line_color='black', 
                font_size = 12,
                barmode = barmode
            )
 
def add_yaxis2_layout(title):

    return dict(
                title=title,
                titlefont=dict(color="#ff7f0e"),
                tickfont=dict(color="#ff7f0e"),
                anchor="free",
                overlaying="y",
                side="right",
                position=1
    )


def get_fig_with_line_plot(df = None, x= None, y=None, color = None, color_discrete_map = None, category_orders=None):

    return px.line(df, x=x, y=y,
                color= color,
                color_discrete_map=color_discrete_map,
                category_orders=category_orders,
                title="Date vs Time",
                labels={x: "test", y: "Sucees"}
            )


def data_not_found_fig(fig, title):
    fig.update_layout(
            title_text=title,
            title=dict(x=0.5),
            xaxis =  { "visible": False },
            yaxis = { "visible": False },
            annotations = [
                {   
                    "text": "No data for given RUN name",
                    "showarrow": False,
                    "font": {
                        "size": 20
                    }
                }
            ]
        )
    return fig

                
