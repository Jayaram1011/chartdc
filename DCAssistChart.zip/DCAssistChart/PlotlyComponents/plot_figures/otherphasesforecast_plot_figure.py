import pandas as pd
import plotly.graph_objects as go

from DCAssistChart.PlotlyComponents.plot_figures.plot_figures_utils import (
    data_not_found_fig, graph_layout, scatter_plot)
from DCAssistChart.PlotlyComponents.utils.ploty_constant import (
    COLOR_MAPPING_DICT, OTHERPHASEFORECAST)


def otherphasesforecast_plot_figure(p_case_well_levels_list, df_p_case_well_levels_list,units,plot_name):

    data = []

    for index, value in enumerate(p_case_well_levels_list):
        if not df_p_case_well_levels_list[index].empty:
            trace_PCaseWellLevels = scatter_plot(data_frame = df_p_case_well_levels_list[index], x=OTHERPHASEFORECAST[plot_name]['x_axis_dfcol'], y=OTHERPHASEFORECAST[plot_name]['y_axis_dfcol'], color=COLOR_MAPPING_DICT[value], name = value)
            data.append(trace_PCaseWellLevels)
    
    xaxis_title = OTHERPHASEFORECAST[plot_name]['x_axis_title']
    yaxis_title = OTHERPHASEFORECAST[plot_name]['y_axis_title'] 
    # if units:
    #      yaxis_title = yaxis_title + "("+units['GOR']+")"
    layout = graph_layout(legend_title= OTHERPHASEFORECAST[plot_name]['legend_title'], title = OTHERPHASEFORECAST[plot_name]['title'], xaxis = xaxis_title, yaxis = yaxis_title)

    fig = go.Figure(data=data,layout=layout)

    return fig

def get_data_not_found_fig(title):
    fig = go.Figure()
    fig = data_not_found_fig(fig, title)
    return fig

