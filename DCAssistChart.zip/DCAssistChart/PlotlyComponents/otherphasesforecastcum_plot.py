from DCAssistChart.PlotlyComponents.plot_figures.otherphasesforecastcum_plot_figure import (
    get_data_not_found_fig, otherphasesforecastcum_plot_figure)
from DCAssistChart.PlotlyComponents.utils.df_queries import (
    get_filtered_df, get_integrated_output_df, rename_columncontent_df)
from DCAssistChart.PlotlyComponents.utils.helper import get_file_path
from DCAssistChart.PlotlyComponents.utils.ploty_constant import (
    INTEGRATED_OUTPUT_CSV, INTEGRATED_OUTPUT_FULL_CSV, OTHERPHASEFORECASTCUM,
    P_CASE_WELL_LEVEL_ALLCASES)
from runalgorithm.helper import get_run_dir


def gorvscumulativevolume(dropdown_value,otherphasesforecastcum_data):
    if dropdown_value in otherphasesforecastcum_data['uniqueids']:
        runid, well_type = otherphasesforecastcum_data['uniqueids'][dropdown_value].split(',') 
        
        file_name = INTEGRATED_OUTPUT_CSV
        if otherphasesforecastcum_data["allcases"] == True:
            file_name = INTEGRATED_OUTPUT_FULL_CSV

        path = get_run_dir(otherphasesforecastcum_data['assetdb'], runid)
        integrated_output_path = get_file_path(path,file_name)
        df = get_integrated_output_df(integrated_output_path, OTHERPHASEFORECASTCUM['gorvscumulativevolume']['use_colunms'])
        df = rename_columncontent_df(df)

        p_case_well_levels_list = OTHERPHASEFORECASTCUM['gorvscumulativevolume']['PCase_well_filter']
        if otherphasesforecastcum_data["allcases"] == True:
            p_case_well_levels_list = P_CASE_WELL_LEVEL_ALLCASES

        df_p_case_well_levels_list = []

        for index, value in enumerate(p_case_well_levels_list):
            
            p_case_and_uniqueid_filter_df = get_filtered_df(df, dropdown_value, _filters = [p_case_well_levels_list[index]])

            df_p_case_well_levels_list.append(p_case_and_uniqueid_filter_df)
            
        df_history = get_filtered_df(df, dropdown_value, _filters = ['History'])
    
        fig = otherphasesforecastcum_plot_figure(p_case_well_levels_list, df_p_case_well_levels_list,plot_name='gorvscumulativevolume')
        return fig
        
    else:
        return get_data_not_found_fig(title= OTHERPHASEFORECASTCUM['gorvscumulativevolume']['title'])
    
def worvscumulativevolume(dropdown_value,otherphasesforecastcum_data):
        
    if dropdown_value in otherphasesforecastcum_data['uniqueids']:
        runid, well_type = otherphasesforecastcum_data['uniqueids'][dropdown_value].split(',')
         
        file_name = INTEGRATED_OUTPUT_CSV
        if otherphasesforecastcum_data["allcases"] == True:
            file_name = INTEGRATED_OUTPUT_FULL_CSV

        path = get_run_dir(otherphasesforecastcum_data['assetdb'], runid)
        integrated_output_path = get_file_path(path,file_name)
        df = get_integrated_output_df(integrated_output_path, OTHERPHASEFORECASTCUM['worvscumulativevolume']['use_colunms'])
        df = rename_columncontent_df(df)

        p_case_well_levels_list = OTHERPHASEFORECASTCUM['worvscumulativevolume']['PCase_well_filter']
        if otherphasesforecastcum_data["allcases"] == True:
            p_case_well_levels_list = P_CASE_WELL_LEVEL_ALLCASES

        df_p_case_well_levels_list = []

        for index, value in enumerate(p_case_well_levels_list):

            p_case_and_uniqueid_filter_df = get_filtered_df(df, dropdown_value, _filters = [p_case_well_levels_list[index]])

            df_p_case_well_levels_list.append(p_case_and_uniqueid_filter_df)


        df_history = get_filtered_df(df, dropdown_value, _filters = ['History'])
          
        fig = otherphasesforecastcum_plot_figure(p_case_well_levels_list, df_p_case_well_levels_list,plot_name='worvscumulativevolume')
        return fig
        
    else:
        return get_data_not_found_fig(title= OTHERPHASEFORECASTCUM['worvscumulativevolume']['title'])
    
def watercutvscumulativevolume(dropdown_value,otherphasesforecastcum_data):
          
    if dropdown_value in otherphasesforecastcum_data['uniqueids']:
        runid, well_type = otherphasesforecastcum_data['uniqueids'][dropdown_value].split(',')
         
        file_name = INTEGRATED_OUTPUT_CSV
        if otherphasesforecastcum_data["allcases"] == True:
            file_name = INTEGRATED_OUTPUT_FULL_CSV

        path = get_run_dir(otherphasesforecastcum_data['assetdb'], runid)
        integrated_output_path = get_file_path(path,file_name)
        df = get_integrated_output_df(integrated_output_path, OTHERPHASEFORECASTCUM['watercutvscumulativevolume']['use_colunms'])
        df = rename_columncontent_df(df)

        p_case_well_levels_list = OTHERPHASEFORECASTCUM['watercutvscumulativevolume']['PCase_well_filter']
        if otherphasesforecastcum_data["allcases"] == True:
            p_case_well_levels_list = P_CASE_WELL_LEVEL_ALLCASES

        df_p_case_well_levels_list = []

        for index, value in enumerate(p_case_well_levels_list):

            p_case_and_uniqueid_filter_df = get_filtered_df(df, dropdown_value, _filters = [p_case_well_levels_list[index]])

            df_p_case_well_levels_list.append(p_case_and_uniqueid_filter_df)
    

        df_history = get_filtered_df(df, dropdown_value, _filters = ['History'])
        
        fig = otherphasesforecastcum_plot_figure(p_case_well_levels_list, df_p_case_well_levels_list,plot_name='watercutvscumulativevolume')
        return fig
        
    else:
        return get_data_not_found_fig(title= OTHERPHASEFORECASTCUM['watercutvscumulativevolume']['title'])



