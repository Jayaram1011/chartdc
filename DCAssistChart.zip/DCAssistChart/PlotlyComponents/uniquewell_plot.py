from runalgorithm.helper import get_run_dir
from DCAssistChart.PlotlyComponents.utils.ploty_constant import INTEGRATED_OUTPUT_CSV, UNIQUEWELL
from DCAssistChart.PlotlyComponents.utils.helper import get_file_path
from DCAssistChart.PlotlyComponents.utils.df_queries import get_integrated_output_df, rename_columncontent_df, get_filtered_df, get_outlier_history_df, empty_df
from DCAssistChart.PlotlyComponents.plot_figures.uniquewell_plot_figure import uniquewell_plot_figure, get_data_not_found_fig
from runalgorithm.tests import PDAlgorithmTests


def ratevsdatevscum(dropdown_value,uniquewell_data,outlier_data):

    if dropdown_value in uniquewell_data['uniqueids']:
        runid, well_type = uniquewell_data['uniqueids'][dropdown_value].split(',')
         
        file_name = INTEGRATED_OUTPUT_CSV
        path = get_run_dir(uniquewell_data['assetdb'], runid)
        integrated_output_path = get_file_path(path,file_name)
        df = get_integrated_output_df(integrated_output_path, UNIQUEWELL['use_colunms'])
        df = rename_columncontent_df(df)

        df_P10 = get_filtered_df(df, dropdown_value, _filters = [UNIQUEWELL['PCase_well_filter'][0]])
        df_P50 = get_filtered_df(df, dropdown_value, _filters = [UNIQUEWELL['PCase_well_filter'][1]])
        df_P90 = get_filtered_df(df, dropdown_value, _filters = [UNIQUEWELL['PCase_well_filter'][2]])

        df_history = get_filtered_df(df, dropdown_value, _filters = ['History'])
        df_decline_period = df[[UNIQUEWELL['ratevsdate']['x_axis_dfcol'], UNIQUEWELL['ratevsdate']['y2_axis_dfcol']]]

        outlier_history_path = get_file_path(path, "Outlier_History_Data.csv")
        df_outlier_history = get_outlier_history_df(outlier_history_path, UNIQUEWELL['use_colunms_outlier_history'])

        df_selected_outlier = empty_df()
        if dropdown_value in outlier_data and not uniquewell_data['system']:
            db_dates = outlier_data[dropdown_value]
            dates = db_dates

            if not df_outlier_history.empty:
                file_dates = df_outlier_history['Date'].to_list()
                file_dates = [str(date.to_pydatetime()).split()[0] for date in file_dates]
                dates = [date for date in db_dates if date not in file_dates]

            if dates:
                df_selected_outlier = df_history.loc[df_history['Date'].isin(dates)]
        
        fig = uniquewell_plot_figure(df_P10,df_P50,df_P90,df_history,df_decline_period,well_type, df_selected_outlier, df_used_outlier = df_outlier_history)
        return fig
        
    else:
        return get_data_not_found_fig(title= UNIQUEWELL['ratevsdate']['title'])
