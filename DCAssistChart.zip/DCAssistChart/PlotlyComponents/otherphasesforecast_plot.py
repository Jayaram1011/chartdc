from DCAssistChart.PlotlyComponents.plot_figures.otherphasesforecast_plot_figure import (
    get_data_not_found_fig, otherphasesforecast_plot_figure)
from DCAssistChart.PlotlyComponents.utils.df_queries import (
    get_filtered_df, get_integrated_output_df, rename_columncontent_df)
from DCAssistChart.PlotlyComponents.utils.helper import get_file_path
from DCAssistChart.PlotlyComponents.utils.ploty_constant import (
    INTEGRATED_OUTPUT_CSV, INTEGRATED_OUTPUT_FULL_CSV, OTHERPHASEFORECAST,
    P_CASE_WELL_LEVEL_ALLCASES)
from runalgorithm.helper import get_run_dir


def gorvsdate(dropdown_value,otherphasesforecast_data):
    
    if dropdown_value in otherphasesforecast_data['uniqueids']:
        runid, well_type = otherphasesforecast_data['uniqueids'][dropdown_value].split(',')
         
        file_name = INTEGRATED_OUTPUT_CSV
        if otherphasesforecast_data["allcases"] == True:
            file_name = INTEGRATED_OUTPUT_FULL_CSV

        path = get_run_dir(otherphasesforecast_data['assetdb'], runid)
        integrated_output_path = get_file_path(path,file_name)
        df = get_integrated_output_df(integrated_output_path, OTHERPHASEFORECAST['gorvsdate']['use_colunms'])
        df = rename_columncontent_df(df)

        p_case_well_levels_list = OTHERPHASEFORECAST['gorvsdate']['PCase_well_filter']
        if otherphasesforecast_data["allcases"] == True:
            p_case_well_levels_list = P_CASE_WELL_LEVEL_ALLCASES

        df_p_case_well_levels_list = []

        for index, value in enumerate(p_case_well_levels_list):

            p_case_and_uniqueid_filter_df = get_filtered_df(df, dropdown_value, _filters = [p_case_well_levels_list[index]])

            df_p_case_well_levels_list.append(p_case_and_uniqueid_filter_df)
        
        df_history = get_filtered_df(df, dropdown_value, _filters = ['History'])
    
        fig = otherphasesforecast_plot_figure(p_case_well_levels_list, df_p_case_well_levels_list,units = otherphasesforecast_data['units'],plot_name='gorvsdate')
        return fig
        
    else:
        return get_data_not_found_fig(title= OTHERPHASEFORECAST['gorvsdate']['title'])
    
def worvsdate(dropdown_value,otherphasesforecast_data):
        
    if dropdown_value in otherphasesforecast_data['uniqueids']:
        runid, well_type = otherphasesforecast_data['uniqueids'][dropdown_value].split(',')
         
        file_name = INTEGRATED_OUTPUT_CSV
        if otherphasesforecast_data["allcases"] == True:
            file_name = INTEGRATED_OUTPUT_FULL_CSV

        path = get_run_dir(otherphasesforecast_data['assetdb'], runid)
        integrated_output_path = get_file_path(path,file_name)
        df = get_integrated_output_df(integrated_output_path, OTHERPHASEFORECAST['worvsdate']['use_colunms'])
        df = rename_columncontent_df(df)

        p_case_well_levels_list = OTHERPHASEFORECAST['worvsdate']['PCase_well_filter']
        if otherphasesforecast_data["allcases"] == True:
            p_case_well_levels_list = P_CASE_WELL_LEVEL_ALLCASES

        df_p_case_well_levels_list = []

        for index, value in enumerate(p_case_well_levels_list):

            p_case_and_uniqueid_filter_df = get_filtered_df(df, dropdown_value, _filters = [p_case_well_levels_list[index]])

            df_p_case_well_levels_list.append(p_case_and_uniqueid_filter_df)

        df_history = get_filtered_df(df, dropdown_value, _filters = ['History'])
          
        fig = otherphasesforecast_plot_figure(p_case_well_levels_list, df_p_case_well_levels_list,units = otherphasesforecast_data['units'],plot_name='worvsdate')
        return fig
        
    else:
        return get_data_not_found_fig(title= OTHERPHASEFORECAST['worvsdate']['title'])
    
def watercutvsdate(dropdown_value,otherphasesforecast_data):
        
    if dropdown_value in otherphasesforecast_data['uniqueids']:
        runid, well_type = otherphasesforecast_data['uniqueids'][dropdown_value].split(',')
         
        file_name = INTEGRATED_OUTPUT_CSV
        if otherphasesforecast_data["allcases"] == True:
            file_name = INTEGRATED_OUTPUT_FULL_CSV

        path = get_run_dir(otherphasesforecast_data['assetdb'], runid)
        integrated_output_path = get_file_path(path,file_name)
        df = get_integrated_output_df(integrated_output_path, OTHERPHASEFORECAST['watercutvsdate']['use_colunms'])
        df = rename_columncontent_df(df)

        p_case_well_levels_list = OTHERPHASEFORECAST['watercutvsdate']['PCase_well_filter']
        if otherphasesforecast_data["allcases"] == True:
            p_case_well_levels_list = P_CASE_WELL_LEVEL_ALLCASES

        df_p_case_well_levels_list = []

        for index, value in enumerate(p_case_well_levels_list):

            p_case_and_uniqueid_filter_df = get_filtered_df(df, dropdown_value, _filters = [p_case_well_levels_list[index]])

            df_p_case_well_levels_list.append(p_case_and_uniqueid_filter_df)
    
    
        df_history = get_filtered_df(df, dropdown_value, _filters = ['History'])
        print(df)   
        fig = otherphasesforecast_plot_figure(p_case_well_levels_list, df_p_case_well_levels_list,units = otherphasesforecast_data['units'],plot_name='watercutvsdate')
        return fig
        
    else:
        return get_data_not_found_fig(title= OTHERPHASEFORECAST['watercutvsdate']['title'])




