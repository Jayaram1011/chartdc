from django.shortcuts import render

# Create your views here.

def get_user_assetdb(request):
    userid = request.dcauser
    assetdb = request.assetdb
    return userid, assetdb

def get_user_assetdb_system(request):
    userid, assetdb = get_user_assetdb(request)
    system = request.GET.get('system')
    return userid, assetdb, system

def uniquewell_view(request):
    userid, assetdb, system = get_user_assetdb_system(request)
    session = request.session
    context = {'userid': userid, 'assetdb': assetdb, 'system': system}
    session['django_plotly_dash'] = context
    return render(request, 'DCAssistChart/uniquewell.html')

def otherphasesforecast_view(request):
    userid, assetdb, system = get_user_assetdb_system(request)
    session = request.session
    context = {'userid': userid, 'assetdb': assetdb, 'system': system,'allcases':False}
    session['django_plotly_dash'] = context
    return render(request, 'DCAssistChart/otherphasesforecast.html')

def otherphasesforecastallcases_view(request):
    userid, assetdb, system = get_user_assetdb_system(request)
    session = request.session
    context = {'userid': userid, 'assetdb': assetdb, 'system': system,'allcases':True}
    session['django_plotly_dash'] = context
    return render(request, 'DCAssistChart/otherphasesforecast.html')


def otherphasesforecastcum_view(request):
    userid, assetdb, system = get_user_assetdb_system(request)
    session = request.session
    context = {'userid': userid, 'assetdb': assetdb, 'system': system,'allcases':False}
    session['django_plotly_dash'] = context
    return render(request, 'DCAssistChart/otherphasesforecastcum.html')

def otherphasesforecastcumallcases_view(request):
    userid, assetdb, system = get_user_assetdb_system(request)
    session = request.session
    context = {'userid': userid, 'assetdb': assetdb, 'system': system,'allcases':True}
    session['django_plotly_dash'] = context
    return render(request, 'DCAssistChart/otherphasesforecast.html')


def probabilisticvsarithmetic_view(request):
    userid, assetdb, system = get_user_assetdb_system(request)
    session = request.session
    context = {'userid': userid, 'assetdb': assetdb, 'system': system,'allcases':False}
    session['django_plotly_dash'] = context
    return render(request, 'DCAssistChart/probabilisticvsarithmetic.html')

def probabilisticvsarithmeticallcases(request):
    userid, assetdb, system = get_user_assetdb_system(request)
    session = request.session
    context = {'userid': userid, 'assetdb': assetdb, 'system': system,'allcases':True}
    session['django_plotly_dash'] = context
    return render(request, 'DCAssistChart/probabilisticvsarithmetic.html')










